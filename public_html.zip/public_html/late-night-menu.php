<?php 
$title = 'Late Night Menu';
include 'header.php'; ?>
<!--Main-->
<div id="main">
  <!--TAB STYLE 1-->
  <!--MENU-->
  <section class="tab-style-2">
    <!-- container -->
    <div class="container">
      <!-- row -->
      <div class="row">
        <!--- first col -->
        <div class="col-md-12 col-xs-12">
          <!-- menu box-->
          <div class="menu-box">
            <!-- Text col-->
            <div class="text-col mx-auto">
              <h2>Late Night Menu</h2>
              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title"> 128
N
A
C
H
O
S </strong><br><small>Jalapeno, Chipotle Black Beans, Pico de Gallo, Guacamole, and Queso Blanco Sauce. Chicken +$5, Beef +$6.</small></p>
</small>
                    </p>
                </div>
                <strong class="amount">$14.00</strong> 
               </div>
              <!-- #Text box-->


              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title"> FRENCH ONION SOUP </strong><br>
                  <small>   Swiss, Provolone, Crostini </small> </p>
                </div>
                <strong class="amount">$8.00 </strong> </div>
              <!-- #Text box-->
            </div>
            <!-- #Text col -->
          </div>
          <!-- #menu box -->
        </div>
        <!-- #first col -->
      </div>
      <!-- #row -->
    </div>
    <!-- #container -->
  </section>
</div>
<!-- #main -->
<!--Main-->
<?php include 'footer.php'; ?>
