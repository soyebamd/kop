
<?php
$title = 'Drinks';
include 'header.php'; ?>
<!--Main-->
<div id="main">
  <!--TAB STYLE 1-->
  <!--MENU-->
  <section class="tab-style-2">
    <div class="container">
      <div class="row">
        <div class="col-md-6 col-xs-12">
          <div class="tab-content">
            <div role="tabpanel" class="tab-pane active" id="tab-1">
              <div class="menu-box">
                <div class="text-col">
                  <div class="text-box-outer">
                    <div class="text-box">
                      <h2>Cocktails</h2>
                     




<p>Moscow Mule</p>
    <p>Lemon Drop Martini</p>
    <p>Smoked Bourbon</p>
    <p>Apperol Spritz</p>
    <p>Koplemonade</p>
    <p>Spiked Arnold Palmer</p>
    <p>Manhattan</p>
    <p>Perfect Patron Margarita</p>
    <p>Cadillac Margarita</p>
    <p>Mimosa Towers</p>
    <p>Mojito</p>
    <p>Strawberry Mojito</p>
    <p>Beer Buckets</p>
    <p>Stateside and Surfside</p>




                    </div>
                  </div>
                 
               


                  
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 <div class="text-box-outer">
                    <div class="text-box">
                      <h2>wine</h2>


                      <p><strong>WHITE</strong></p>
                      <p>Pinot Grigio. Chardonnay. Moscato</p>

                      <br>


                      <p><strong>RED</strong></p>
                      <p>Cabernet Sauvignon. Pinot Noir. Merlot. Rioja. Shiraz.</p>


                      <br>

                      
                      <p><strong>ROSE</strong></p>
                      <p>Prosecco</p>



                    </div>
                  </div>
                 
                 
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-xs-12">
          <div class="tab-content">
            <div role="tabpanel" class="tab-pane active" id="tab-1">
              <div class="menu-box">
                <div class="text-col">
                  <div class="text-box-outer">
                    <div class="text-box">
                      <h2>Beer</h2>
                      
                      <p>Bottled</p>
<p>Sam Adams Water Lager</p>
<p>Sam Adams Boston Lager</p>
<p>Michelob Ultra</p>
<p>Corona</p>
<p>Bass</p>
<br>

<p>BOTTLED IPA</p>
<p>VICTORY GOLDEN MONET</p>
<p>VICTORY HOP DEVIL</p>
<p>YARDS LEVELUP</p>
<p>GUINNESS DRAUGHT STOUT</p>

<br>

<p>Spiked</p>
<p>Mike's Hard Lemonade</p>
<p>Arnies Spiked Lemonade</p>
<p>White Claw</p>
<p>Twisted Tea</p>


<br>

<p>On Tap</p>
<p>Coors Light</p>
<p>Coors Banquet</p>
<p>Michelob Ultra</p>
<p>Angry Orchard</p>
<p>Lagunitas</p>
<p>Cape May IPA</p>
<p>Cape May Coastal Evacuation</p>
<p>Workhorse New England</p>
<p>Twisted Tea</p>

<br>

<p>On Tap</p>
<p>Modelo</p>
<p>Miller Light</p>
<p>Yuengling</p>
<p>Blue Moon</p>
<p>Guinness</p>
<p>Stella</p>
<p>Heineken</p>
<p>Angry Orchard</p>
<p>Bud</p>

                    </div>
                  </div>
                
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    
  <p class="text-center mx-5" style="    clear: both;
    margin: 7% 0 0 0;
    display: block;">Chet Patel</p>

    
  </section>
</div>
<!--Main-->
<?php include 'footer.php'; ?>