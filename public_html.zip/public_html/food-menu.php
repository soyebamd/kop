<?php 
$title = 'Food Menu';
include 'header.php'; ?>
<!--Main-->
<div id="main">
  <!--TAB STYLE 1-->
  <!--MENU-->
  <section class="tab-style-2">
    <!-- container -->
    <div class="container">

      <h1 class="text-white fw-bold mt-7">FOOD MENU</h1>
      <!-- row -->
      <div class="row">
        <!--- first col -->
        <div class="col-md-6 col-xs-12">
          <!-- menu box-->
          <div class="menu-box">
            <!-- Text col-->
            <div class="text-col">
              <h2>Starters</h2>
              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">BRUSSELSPROUTS</strong><br>
                    <small>Jalapeno, Sweet Chili, Lime Aioli.</small>
                  </p>
                </div>
                <strong class="amount">$8.00</strong>
              </div>
              <!-- #Text box-->

              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">CHICKEN QUESADILLA</strong><br>
                    <small>Pico de Gallo, Cheddar Jack, Fresh Cilantro.</small>
                  </p>
                </div>
                <strong class="amount">$11.00</strong>
              </div>
              <!-- #Text box-->

              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">CRISPY CHICKEN WINGS</strong><br>
                    <small>Buffalo, Sweet Chili, Garlic Parm, Jerk, Lemon Pepper.</small>
                  </p>
                </div>
                <strong class="amount">$13.00</strong>
              </div>
              <!-- #Text box-->

              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">DANIEL’S CRISPY COCONUT SHRIMP (5pc)</strong><br>
                    <small>Sweet Chili Dipping Sauce.</small>
                  </p>
                </div>
                <strong class="amount">$14.00</strong>
              </div>
              <!-- #Text box-->

              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">FishTacos (3pc).</strong><br>
                  </p>
                </div>
                <strong class="amount">$12.00</strong>
              </div>
              <!-- #Text box-->

              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">Housemade mozzarella planks</strong><br>
                    <small>5pc w/Traditional Sauce.</small>
                  </p>
                </div>
                <strong class="amount">$9.00</strong>
              </div>
              <!-- #Text box-->

              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">128 NACHOS</strong><br>
                    <small>Jalapeno, Chipotle Black Beans, Pico de Gallo, </small><br>
                    <small>Guacamole, Queso Blanco Cheddar Sauce</small><br>
                    <small>Chicken +5, Beef +6.</small>
                  </p>
                </div>
                <strong class="amount">$12.00</strong>
              </div>
              <!-- #Text box-->

              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">POPPER ROLLS (3PC)</strong><br>
                    <small>Fresh Jalapeño Peppers Filled with Cheese.</small>
                  </p>
                </div>
                <strong class="amount">$11.00</strong>
              </div>
              <!-- #Text box-->

              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">SLIDER TWINS</strong><br>
                    <small>Angus, Fried Chicken, Carolina Pulled Pork.</small>
                  </p>
                </div>
                <strong class="amount">$11.00</strong>
              </div>
              <!-- #Text box-->

              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">CLASSIC POTATO SKINS</strong><br>
                    <small>Cheddar Jack, Applewood Bacon, Green Onions, and Queso Blanco Cheese Sauce.</small>
                  </p>
                </div>
                <strong class="amount">$9.00</strong>
              </div>
              <!-- #Text box-->

              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">GIANT SOFT PRETZEL</strong><br>
                    <small>Kop Cheese Sauce, Spicy Mustard.</small>
                  </p>
                </div>
                <strong class="amount">$9.00</strong>
              </div>
              <!-- #Text box-->

              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">RED PEPPER HUMMUS (VEG)</strong><br>
                    <small>Tahini, Lemon, Toasted Pita, Carrot and Celery.</small>
                  </p>
                </div>
                <strong class="amount">$9.00</strong>
              </div>
              <!-- #Text box-->

              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">CRISP CHICKEN TENDERS</strong><br>
                  </p>
                </div>
                <strong class="amount">$10.00</strong>
              </div>
              <!-- #Text box-->
            </div>
            <!-- Text col-->
            <div class="text-col m-top-5">
              <h2>Entrees</h2>
              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">KITCHEN SURPRISEPASTA</strong><br>
                    <small>Chef's Random Pasta of the Week</small>
                  </p>
                </div>
                <strong class="amount">?</strong>
              </div>
              <!-- #Text box-->

              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">ATLANTIC FLOUNDER (GF)</strong><br>
                    <small>Grilled or Fried Flounder, Herb Rice, Roasted Broccoli, Lemon Butter Sauce.</small>
                  </p>
                </div>
                <strong class="amount">$24.00</strong>
              </div>
              <!-- #Text box-->

              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">Fried Chicken Platter</strong><br>
                    <small>Mac & Cheese, Green Beans.</small>
                  </p>
                </div>
                <strong class="amount">$18.00</strong>
              </div>
              <!-- #Text box-->

              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">PINEAPPLE SALSA SALMON (GF)</strong><br>
                    <small>Bourbon Pineapple Glazed Salmon, Pineapple Salsa, Rice.</small>
                  </p>
                </div>
                <strong class="amount">$26.00</strong>
              </div>
              <!-- #Text box-->

              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">RibeyeSTEAK</strong><br>
                    <small>Green Beans, Roasted Potatoes, Chimichurri Onions +1, Mushrooms +1.</small>
                  </p>
                </div>
                <strong class="amount">$25.00</strong>
              </div>
              <!-- #Text box-->

              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">128 NACHOS</strong><br>
                    <small>Jalapeno, Chipotle Black Beans, Pico de Gallo, Guacamole, Queso Blanco Cheddar Sauce Chicken +5, Beef +6.</small>
                  </p>
                </div>
                <strong class="amount">$12.00</strong>
              </div>
              <!-- #Text box-->

              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">VEGETABLESTIRFRY WITH RICE</strong><br>
                    <small>CHICKEN +5,TOFU+5,SHRIMP+6,STEAK +6.</small>
                  </p>
                </div>
                <strong class="amount">$15.00</strong>
              </div>
              <!-- #Text box-->

              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">ZUCCHINISPAGHETTI (VEG)</strong><br>
                    <small>House-Made Marinara, Eggplant Meatballs, Parmesan Cheese.</small>
                  </p>
                </div>
                <strong class="amount">$16.00</strong>
              </div>
              <!-- #Text box-->

              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">ZUCCHINISPAGHETTI (VEG)</strong><br>
                    <small>House-Made Marinara, Eggplant Meatballs, Parmesan Cheese.</small>
                  </p>
                </div>
                <strong class="amount">$16.00</strong>
              </div>
              <!-- #Text box-->
            </div>
            <!-- #Text col-->

             <!-- Text col-->
             <div class="text-col  m-top-5">
              <h2>Salads</h2>
              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">mixed greens</strong><br>
                    <small>Tomato, Cucumber, Carrot, Croutons, Maple Mustard Vinaigrette.</small>
                  </p>
                </div>
                <strong class="amount">$8.00</strong>
              </div>
              <!-- #Text box-->

              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">CAESAR SALAD</strong><br>
                    <small>Romaine, Housemade Caesar Dressing, Croutons, Parm. Chicken +5, Grilled Shrimp +6, Grilled Salmon +8.</small>
                  </p>
                </div>
                <strong class="amount">$9.00</strong>
              </div>
              <!-- #Text box-->

              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">BLACKENED CHICKEN CHOP SALAD</strong><br>
                    <small>Avocado Ranch, Tomato, Black Beans, Tortilla Chips, Cheddar Jack Cheese.</small>
                  </p>
                </div>
                <strong class="amount">$14.00</strong>
              </div>
              <!-- #Text box-->

              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">GREEK SALAD</strong><br>
                    <small>Spring Mix, Feta, Tomato, Olives, Fresh Chicken, Croutons, Onion, Peppers, Red Wine Vinaigrette.</small>
                  </p>
                </div>
                <strong class="amount">$14.00</strong>
              </div>
              <!-- #Text box-->

              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">Rice Bowl</strong><br>
                    <small>Choice of Chicken, Steak, or Shrimp Rice, Pico de Gallo, Mixed Lettuce, Black Beans, Mixed Cheese, Tortilla Chips, Topped with Avocado.</small>
                  </p>
                </div>
                <strong class="amount">$19.00</strong>
              </div>
              <!-- #Text box-->

              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">ATLANTIC FLOUNDER</strong><br>
                    <small>Grilled or Fried Flounder, Herb Rice Pilaf, Roasted Broccoli, Lemon Butter Sauce.</small>
                  </p>
                </div>
                <strong class="amount">$24.00</strong>
              </div>
              <!-- #Text box-->
            </div>
            <!-- #Text col-->


          </div>
          <!-- #menu box-->
        </div>
        <!--- #first col -->

        <!--- second col -->
        <div class="col-md-6 col-xs-12">
          <!-- menu box-->
          <div class="menu-box">
           

            <!-- Text col-->
            <div class="text-col ">
              <div class="d-flex">
              <h2>Sides</h2>
              <strong class="amount">$5.00</strong>
</div>
              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">POTATOES:</strong><br>
                <small>MASHED OR REDSKIN</small>              
              </p>
                </div>
               
              </div>
              <!-- #Text box-->

              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">FRENCHFRIES</strong></p>
                </div>
                
              </div>
              <!-- #Text box-->

              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">MAC 'N' CHEESE</strong></p>
                </div>
               
              </div>
              <!-- #Text box-->

              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">CRISPYBRUSSELS</strong></p>
                </div>
              
              </div>
              <!-- #Text box-->

              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">ROASTED BROCCOLI (GF)</strong></p>
                </div>
               
              </div>
              <!-- #Text box-->

              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">GREEN BEANS(GF)</strong></p>
                </div>
               
              </div>
              <!-- #Text box-->

              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">HERB RICE</strong></p>
                </div>
                
              </div>
              <!-- #Text box-->

           
            </div>
            <!-- #Text col-->


















             <!-- Text col-->
             <div class="text-col m-top-5">
              <div class="d-flex">
              <h2>Beverages</h2>
              <strong class="amount">$3.00</strong>
</div>
              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">COKE, DIET COKE</strong><br>
                    
              </p>
                </div>
               
              </div>
              <!-- #Text box-->

              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">SPRITE</strong></p>
                </div>
                
              </div>
              <!-- #Text box-->
              





              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">ROOT BEER</strong></p>
                </div>
                <strong class="amount">$4.00</strong>
              </div>
              <!-- #Text box-->

              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">APPLE JUICE</strong></p>
                </div>
              
              </div>
              <!-- #Text box-->

              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">CRANBERRY JUICE</strong></p>
                </div>
               
              </div>
              <!-- #Text box-->

              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">LEMONADE</strong></p>
                </div>
               
              </div>
              <!-- #Text box-->

              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">ORANGE JUICE</strong></p>
                </div>
                
              </div>
              <!-- #Text box-->


              
              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">MILK, CHOCOLATE MILK
</strong></p>
                </div>
                
              </div>
              <!-- #Text box-->

            
              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">COFFEE, HOT COFFEE</strong></p>
                </div>
                
              </div>
              <!-- #Text box-->


           
            </div>
            <!-- #Text col-->







              <!-- Text col-->
              <div class="text-col m-top-5">
              <div class="d-flex">
              <h2>Soups</h2>
              
</div>
              

              





              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">SOUP OF THE DAY</strong></p>
                </div>
                <strong class="amount">$7.00</strong>
              </div>
              <!-- #Text box-->



              
              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">FRENCH ONION SOUP</strong></p>
                </div>
                <strong class="amount">$8.00</strong>
              </div>
              <!-- #Text box-->



              
              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">SWISS, PROVOLONE, CROSTINI</strong></p>
                </div>
                
              </div>
              <!-- #Text box-->


              
            


           
            </div>
            <!-- #Text col-->






            

              <!-- Text col-->
              <div class="text-col m-top-5">
              <div class="d-flex">
              <h2>kids</h2>
              
</div>
              

              





              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">QUARTER POUNDER</strong></p>
                </div>
                <strong class="amount">$8.00</strong>
              </div>
              <!-- #Text box-->



              
              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">FRIES</strong></p>
                </div>
                
              </div>
              <!-- #Text box-->



              

              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">CHICKEN TENDERS</strong></p>
                </div>
                <strong class="amount">$7.00</strong>
              </div>
              <!-- #Text box-->

              

              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">WITHFRIES




</strong></p>
                </div>
               
              </div>
              <!-- #Text box-->

            

              

              

              
              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">WITH RED SAUCE</strong></p>
                </div>
              
              </div>
              <!-- #Text box-->








              
              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">MAC AND CHEESE</strong></p>
                </div>
                <strong class="amount">$5.00</strong>
              </div>
              <!-- #Text box-->




              
              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">PERSONAL CHEESE PIZZA</strong></p>
                </div>
                <strong class="amount">$5.00</strong>
              </div>
              <!-- #Text box-->








           
            </div>
            <!-- #Text col-->











          </div>
          <!-- #menu box-->
        </div>
        <!--- #row -->
      </div>
      <!--- #second col -->
    </div>
    <!--- #container -->

    <p class="text-center mx-5" style="clear: both; margin: 7% 0 0 0; display: block;">Chet Patel</p>
  </section>
</div>
<!--Main-->
<?php include 'footer.php'; ?>

This should fix the closing div issue in your PHP code. I added a closing `</div>` tag before the closing `</section>` tag to properly close the `#main` div.
