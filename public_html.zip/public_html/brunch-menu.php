<?php 
$title = 'King of Prussia Tavern Brunch';
include 'header.php'; ?>
<!--Main-->
<div id="main">
  <!--TAB STYLE 1-->
  <!--MENU-->
  <section class="tab-style-2">
  <!-- container -->
  <div class="container">
    <!-- row -->
    <div class="row">
      <!--- first col -->
      <div class="col-md-6 col-xs-12">
        <!-- menu box-->
        <div class="menu-box">
          <!-- Text col-->
          <!-- Text col-->
          <div class="text-col">
            <h2>Brunch Classics</h2>
            <!-- Text box-->
            <div class="text-box-outer">
              <div class="text-box">
                <p> <strong class="menu-title">BERRY PARFAIT <small>(Vegetarian)</small></strong><br>
                  Fresh Berries, Greek Yogurt, and Granola, Mixed Greens Salad </p>
              </div>
              <strong class="amount">$14</strong> </div>
            <!-- #Text box-->
            <!-- Text box-->
            <div class="text-box-outer">
              <div class="text-box">
                <p> <strong class="menu-title">THREE EGG OMELET</strong><br>
                  Served with Redskin Potatoes and Multigrain Toast<br>
                  <strong>Filling Options:</strong> Ham, Bacon, Sausage, Onion, Pepper, 
                  Mushroom, Tomato, Spinach, Broccoli </p>
              </div>
              <strong class="amount">$14</strong> </div>
            <!-- #Text box-->

 <!-- Text box-->
            <div class="text-box-outer">
              <div class="text-box">
                <p> <strong class="menu-title"> EGG PLATTER </strong><br>
                  Two Eggs any Style with Roasted Potatoes and choice of Meat. </p>
              </div>
              <strong class="amount">$11</strong> </div>
            <!-- #Text box-->

               <!-- Text box-->
            <div class="text-box-outer">
              <div class="text-box">
                <p> <strong class="menu-title"> STEAK AND EGGS </strong><br>
                  Sliced Beef Tenderloin, Two Eggs, and Roasted Potatoes. </p>
              </div>
              <strong class="amount">$21</strong> </div>
            <!-- #Text box-->



            <!-- Text box-->
            <div class="text-box-outer">
              <div class="text-box">
                <p> <strong class="menu-title">CHICKEN AND WAFFLES</strong><br>
                  Crispy Waffles topped with Fried Chicken, Maple Syrup, 
                  Applewood Bacon Bits, and Green Onions. Served with Fresh 
                  Fruit </p>
              </div>
              <strong class="amount">$14</strong> </div>
            <!-- #Text box-->
            <!-- Text box-->
            <div class="text-box-outer">
              <div class="text-box">
                <p> <strong class="menu-title">SMOKED SALMON BAGEL</strong><br>
                  Toasted Sesame Bagel with Cream Cheese, Smoked Salmon, 
                  Red Onions, and Capers, Mixed Greens Salad</p>
              </div>
              <strong class="amount">$17</strong> </div>
            <!-- #Text box-->
            <!-- Text box-->
            <div class="text-box-outer">
              <div class="text-box">
                <p> <strong class="menu-title">AVOCADO TOAST<small>(Vegetarian)</small></strong><br>
                  Multigrain Toast, Fresh Avocado, Cilantro, Lime, Scrambled 
                  Eggs, Fresh Fruit Cup</p>
              </div>
              <strong class="amount">$12</strong> </div>
            <!-- #Text box-->
            <!-- Text box-->
            <div class="text-box-outer">
              <div class="text-box">
                <p> <strong class="menu-title">BLUEBERRY PANCAKES</strong><br>
                  3 hubcap sized Pancakes, Fresh Blueberries, Sausage Links</p>
              </div>
              <strong class="amount">$11</strong> </div>
            <!-- #Text box-->
            <!-- Text box-->
            <div class="text-box-outer">
              <div class="text-box">
                <p> <strong class="menu-title">GIANT BREAKFAST SANDWICH</strong><br>
                  3 Scrambled Eggs, Bacon, Ham, Sausage, and Cheddar served 
                  on a Long Roll, Housemade Potato Chips</p>
              </div>
              <strong class="amount">$15</strong> </div>
            <!-- #Text box-->
            <!-- Text box-->
            <div class="text-box-outer">
              <div class="text-box">
                <p> <strong class="menu-title">STRAWBERRIES & CREAM STUFFED 
                  FRENCH TOAST </strong><br>
                  Sweet Vanilla Ricotta, Fresh Strawberries, Crispy Bacon </p>
              </div>
              <strong class="amount">$11</strong> </div>
            <!-- #Text box-->
            <!-- Text box-->
            <div class="text-box-outer">
              <div class="text-box">
                <p> <strong class="menu-title"> EGGS BENEDICT <small>(Vegetarian)</small> </strong><br>
                  Spinach or Canadian Bacon, Poached Egg, English Muffin, Hollandaise, Redskin Potatoes </p>
              </div>
              <strong class="amount">$11</strong> </div>
            <!-- #Text box-->
            <!-- Text box-->
            <div class="text-box-outer">
              <div class="text-box">
                <p> <strong class="menu-title"> KING BREAKFAST </strong><br>
                  Two Eggs, Redskin Potatoes, Bacon, Sausage, Pancakes or French Toast </p>
              </div>
              <strong class="amount">$15</strong> </div>
            <!-- #Text box-->
           
         
            <!-- Text box-->
            <div class="text-box-outer">
              <div class="text-box">
                <p> <strong class="menu-title"> SHRIMP & GRITS </strong><br>
                  Sauteed Shrimp with Peppers, Onions, Applewood Bacon, and Green Onion over Cheesy Corn Grits. </p>
              </div>
              <strong class="amount">$16</strong> </div>
            <!-- #Text box-->
          </div>
          <!-- #Text col-->
          <div class="text-col  m-top-5">
            <h2>Starters & Shareables</h2>
            <!-- Text box-->
            <div class="text-box-outer">
              <div class="text-box">
                <p> <strong class="menu-title"> CRISPY CHICKEN WINGS </strong><br>
                  Served with Blue Cheese, Celery, and one of our signature
                  sauces:<br>
                  Buffalo, Asian, Garlic Herb, or Bourbon BBQ. </p>
              </div>
              <strong class="amount">$13.00 / 8pc</strong> </div>
            <!-- #Text box-->
            <!-- Text box-->
            <div class="text-box-outer">
              <div class="text-box">
                <p> <strong class="menu-title">HOUSEMADE ONION RINGS <small>(Vegetarian)</small></strong><br>
                  With Chipotle Mayo</p>
              </div>
              <strong class="amount">$9.00</strong> </div>
            <!-- #Text box-->
            <!-- Text box-->
            <div class="text-box-outer">
              <div class="text-box">
                <p> <strong class="menu-title">JALAPEÑO POPPER ROLLS <small>(Vegetarian)</small></strong><br>
                  Fresh Jalapeño Peppers stuffed with 3 Cheeses, twisted 
                  into a Spring Roll, fried to a Golden Brown, and served with 
                  Ranch Dressing</p>
              </div>
              <strong class="amount">$11.00 / 3pc</strong> </div>
            <!-- #Text box-->
            <!-- Text box-->
            <div class="text-box-outer">
              <div class="text-box">
                <p> <strong class="menu-title">HOUSEMADE MOZZARELLA PLANKS <small>(Vegetarian)</small> </strong><br>
                  With Traditional Red Sauce</p>
              </div>
              <strong class="amount">$9.00 / 5pc</strong> </div>
            <!-- #Text box-->
            <!-- Text box-->
            <div class="text-box-outer">
              <div class="text-box">
                <p> <strong class="menu-title">RED PEPPER HUMMUS <small>(Vegetarian)</small></strong><br>
                  Tahini, Lemon, Toasted Pita, Carrot, Celery</p>
              </div>
              <strong class="amount">$9.00</strong> </div>
            <!-- #Text box-->
            <!-- Text box-->
            <div class="text-box-outer">
              <div class="text-box">
                <p> <strong class="menu-title">CRISPY BRUSSELS SPROUTS <small>(Vegetarian)</small> </strong><br>
                  Brussels and Jalapeno Slices tossed in Sweet Chili Sauce and 
                  served with Lime Aioli and Toasted Sesame Seeds</p>
              </div>
              <strong class="amount">$8.00</strong> </div>
            <!-- #Text box-->
            <!-- Text box-->
            <div class="text-box-outer">
              <div class="text-box">
                <p> <strong class="menu-title">DANIEL'S CRISPY COCONUT SHRIMP</strong><br>
                  Orange Habanero Dipping Sauce </p>
              </div>
              <strong class="amount">$14.00 / 5pc</strong> </div>
            <!-- #Text box-->
          </div>
          <!-- #Text col-->
        </div>
        <!-- #menu box-->
      </div>
      <!--- #first col -->
      <!--- second col -->
      <div class="col-md-6 col-xs-12 ">
        <!-- menu box-->
        <div class="menu-box">
          <!-- Text col-->
          <div class="text-col">
            <h2>Entree Salads</h2>
            <!-- Text box-->
            <div class="text-box-outer">
              <div class="text-box">
                <p> <strong class="menu-title"> BLACKENED CHICKEN CHOP SALAD </strong><br>
                  Avocado Ranch, Tomato, Black Beans, Tortilla Chips, Cheddar Jack Cheese </p>
              </div>
              <strong class="amount">$14</strong> </div>
            <!-- #Text box-->
            <!-- Text box-->
            <div class="text-box-outer">
              <div class="text-box">
                <p> <strong class="menu-title">GRILLED SHRIMP SALAD </strong><br>
                  Mixed Greens, Peanuts, Carrots, Scallions, Ginger Lime Vin, Crispy Ribbons </p>
              </div>
              <strong class="amount">$15</strong> </div>
            <!-- #Text box-->
            <!-- Text box-->
            <div class="text-box-outer">
              <div class="text-box">
                <p> <strong class="menu-title">GREEK SALAD </strong><br>
                  Spring Mix, Feta, Tomato, Olives, Fresh Chicken, Croutons, Onion, Peppers, Red Wine Vinaigrette </p>
              </div>
              <strong class="amount">$14</strong> </div>
            <!-- #Text box-->
          </div>
          <!-- #Text col-->
          <!-- Text col-->
          <div class="text-col m-top-5">
            <h2> Handhelds </h2>
            <!-- Text box-->
            <div class="text-box-outer">
              <div class="text-box">
                <p> <strong class="menu-title">ANGUS BURGER </strong><br>
                  Grilled Angus Beef topped with Cheddar, Lettuce, Tomato, Red Onion, and Pickles, served with Coated Fries </p>
              </div>
              <strong class="amount">$14</strong> </div>
            <!-- #Text box-->
            <!-- Text box-->
            <div class="text-box-outer">
              <div class="text-box">
                <p> <strong class="menu-title">GRILLED CHICKEN CLUB </strong><br>
                  Grilled Chicken, Herb Mayo, Applewood Bacon, Whole Grain Toast, Creamy Cole Slaw, Lettuce, Tomato </p>
              </div>
              <strong class="amount">$14</strong> </div>
            <!-- #Text box-->
            <!-- Text box-->
            <div class="text-box-outer">
              <div class="text-box">
                <p> <strong class="menu-title"> CRISPY FRIED WHITEFISH </strong><br>
                  Golden Brown Fish Filet, Green Tabasco Remoulade, Lettuce, Tomato, Pickles, House Fried Potato Chips </p>
              </div>
              <strong class="amount">$12</strong> </div>
            <!-- #Text box-->
            <!-- Text box-->
            <div class="text-box-outer">
              <div class="text-box">
                <p> <strong class="menu-title"> BLACK BEAN BURGER </strong><br>
                  House Made Black Bean and Rice Burger on a Kaiser, Shredded Lettuce, Hand Cut Pico de Gallo, Guacamole, Crispy Tortilla Chips</p>
              </div>
              <strong class="amount">$11</strong> </div>
            <!-- #Text box-->
            <!-- Text box-->
            <div class="text-box-outer">
              <div class="text-box">
                <p> <strong class="menu-title"> NORTH CAROLINA PULLED PORK</strong><br>
                  Sweet and Spicy Vinegar BBQ Sauce, Toasted Kaiser Roll, 
                  Creamy Cole Slaw</p>
              </div>
              <strong class="amount">$11</strong> </div>
            <!-- #Text box-->
            <!-- Text box-->
            <div class="text-box-outer">
              <div class="text-box">
                <p> <strong class="menu-title">GOLDEN SEARED CRAB CAKE </strong><br>
                  Toasted Brioche, Green Tabasco Remoulade, Lettuce, & Tomato, House Fried Potato Chips</p>
              </div>
              <strong class="amount">$18</strong> </div>
            <!-- #Text box-->
          </div>
          <!-- #Text col-->
          <!-- SIDES -->
          <div class="text-col m-top-5">
            <h2>Sides</h2>
            <!-- Text box-->
            <div class="text-box-outer">
              <div class="text-box">
                <p> <strong class="menu-title">REDSKIN POTATOES</strong> </p>
              </div>
              <strong class="amount">$5</strong> </div>
            <!-- #Text box-->
            <!-- Text box-->
            <div class="text-box-outer">
              <div class="text-box">
                <p> <strong class="menu-title">FRESH FRUIT CUP</strong> </p>
              </div>
              <strong class="amount">$5</strong> </div>
            <!-- #Text box-->
            <!-- Text box-->
            <div class="text-box-outer">
              <div class="text-box">
                <p> <strong class="menu-title">CRISPY FRENCH FRIES</strong> </p>
              </div>
              <strong class="amount">$5</strong> </div>
            <!-- #Text box-->
            <!-- Text box-->
            <div class="text-box-outer">
              <div class="text-box">
                <p> <strong class="menu-title">HOUSEMADE POTATO CHIPS</strong> </p>
              </div>
              <strong class="amount">$5</strong> </div>
            <!-- #Text box-->
            <!-- Text box-->
            <div class="text-box-outer">
              <div class="text-box">
                <p> <strong class="menu-title">BACON</strong> </p>
              </div>
              <strong class="amount">$5</strong> </div>
            <!-- #Text box-->
            <!-- Text box-->
            <div class="text-box-outer">
              <div class="text-box">
                <p> <strong class="menu-title">SAUSAGE</strong> </p>
              </div>
              <strong class="amount">$5</strong> </div>
            <!-- #Text box-->
            <!-- Text box-->
            <div class="text-box-outer">
              <div class="text-box">
                <p> <strong class="menu-title">TURKEY BACON</strong> </p>
              </div>
              <strong class="amount">$5</strong> </div>
            <!-- #Text box-->

             <!-- Text box-->
            <div class="text-box-outer">
              <div class="text-box">
                <p> <strong class="menu-title">CHEESY GRITS</strong> </p>
              </div>
              <strong class="amount">$5</strong> </div>
            <!-- #Text box-->
            
            <!-- Text box-->
            <div class="text-box-outer">
              <div class="text-box">
                <p> <strong class="menu-title">TOASTED BAGEL</strong> </p>
              </div>
              <strong class="amount">$3</strong> </div>
            <!-- #Text box-->
            <!-- Text box-->
            <div class="text-box-outer">
              <div class="text-box">
                <p> <strong class="menu-title">ENGLISH MUFFIN</strong> </p>
              </div>
              <strong class="amount">$3</strong> </div>
            <!-- #Text box-->
            <!-- Text box-->
            <div class="text-box-outer">
              <div class="text-box">
                <p> <strong class="menu-title">MULTIGRAIN TOAST</strong> </p>
              </div>
              <strong class="amount">$3</strong> </div>
            <!-- #Text box-->
           
          </div>
          <!-- #Text col-->
          <!--# end sides-->
        </div>
        <!-- #Text col-->
      </div>
      <!-- #menu box-->
    </div>
    <!--- #row -->
  </div>
  <!--- #second col -->
</div>
<!--- #container -->


<p class="text-center mx-5" style="    clear: both;
    margin: 7% 0 0 0;
    display: block;">Chet Patel</p>

    
</section>
</div>
<!--Main-->
<?php include 'footer.php'; ?>