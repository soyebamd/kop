<?php 
$title = 'Beverages';
include 'header.php'; ?>
<!--Main-->
<div id="main">
<!--TAB STYLE 1-->
<!--MENU-->
<section class="tab-style-2">
<!-- container -->
<div class="container ">
  <!-- row -->
  <div class="row">
    <!--- first col -->
    <div class="col-md-12 col-xs-12">
      <!-- menu box-->
      <div class="menu-box">
        <!-- Text col-->
        <div class="text-col mx-auto">
          <h2>Beverages Menu</h2>
          <!-- Text box-->
          <div class="text-box-outer">
            <div class="text-box">
              <p><strong class="menu-title">COKE</strong>
              </p>
            </div>
            <strong class="amount">$3.00 </strong> </div>
          <!-- #Text box-->
          <!-- Text box-->
          <div class="text-box-outer">
            <div class="text-box">
              <p><strong class="menu-title">DIET COKE </strong>
                </p>
            </div>
            <strong class="amount">$3.00 </strong> </div>
          <!-- #Text box-->
          <!-- Text box-->
          <div class="text-box-outer">
            <div class="text-box">
              <p><strong class="menu-title">DR. PEPPER </strong>
             </p>
            </div>
            <strong class="amount">$3.00 </strong> </div>
          <!-- #Text box-->
          <!-- Text box-->
          <div class="text-box-outer">
           
         
            <div class="text-box">
              <p><strong class="menu-title">SPRITE </strong></p>
            </div>
            <strong class="amount">$3.00 </strong> </div>
          <!-- #Text box-->



             <!-- Text box-->
             <div class="text-box-outer">
           
         
           <div class="text-box">
             <p><strong class="menu-title">GINGER ALE </strong></p>
           </div>
           <strong class="amount">$3.00 </strong> </div>
         <!-- #Text box-->




            <!-- Text box-->
            <div class="text-box-outer">
           
         
           <div class="text-box">
             <p><strong class="menu-title">UNSWEETENED TEA </strong></p>
           </div>
           <strong class="amount">$3.00 </strong> </div>
         <!-- #Text box-->




            <!-- Text box-->
            <div class="text-box-outer">
           
         
           <div class="text-box">
             <p><strong class="menu-title">LEMONADE </strong></p>
           </div>
           <strong class="amount">$3.00 </strong> </div>
         <!-- #Text box-->



            <!-- Text box-->
            <div class="text-box-outer">
           
         
           <div class="text-box">
             <p><strong class="menu-title">ROOT BEER </strong></p>
           </div>
           <strong class="amount">$4.00 </strong> </div>
         <!-- #Text box-->








         

            <!-- Text box-->
            <div class="text-box-outer">
           
         
           <div class="text-box">
             <p><strong class="menu-title">CRAN JUICE</strong></p>
           </div>
           <strong class="amount">Sm $3.75 | L $4.99</strong> </div>
         <!-- #Text box-->


         

            <!-- Text box-->
            <div class="text-box-outer">
           
         
           <div class="text-box">
             <p><strong class="menu-title">ORANGE JUICE </strong></p>
           </div>
           <strong class="amount">Sm $3.75 | L $4.99</strong> </div>
         <!-- #Text box-->


         

            <!-- Text box-->
            <div class="text-box-outer">
           
         
           <div class="text-box">
             <p><strong class="menu-title">APPLE JUICE</strong></p>
           </div>
           <strong class="amount">Sm $3.75 | L $4.99</strong> </div>
         <!-- #Text box-->





         

            <!-- Text box-->
            <div class="text-box-outer">
           
         
           <div class="text-box">
             <p><strong class="menu-title">MILK </strong></p>
           </div>
           <strong class="amount">$3.50 </strong> </div>
         <!-- #Text box-->




         

            <!-- Text box-->
            <div class="text-box-outer">
           
         
           <div class="text-box">
             <p><strong class="menu-title">CHOCOLATE MILK </strong></p>
           </div>
           <strong class="amount">$3.50 </strong> </div>
         <!-- #Text box-->



         

            <!-- Text box-->
            <div class="text-box-outer">
           
         
           <div class="text-box">
             <p><strong class="menu-title">COFFEE (Reg or Decaf) </strong></p>
           </div>
           <strong class="amount">$3.00 </strong> </div>
         <!-- #Text box-->



          
            <!-- Text box-->
            <div class="text-box-outer">
           
         
           <div class="text-box">
             <p><strong class="menu-title">HOT TEA (Reg or Decaf) </strong></p>
           </div>
           <strong class="amount">$3.00 </strong> </div>
         <!-- #Text box-->



            <!-- Text box-->
            <div class="text-box-outer">
           
         
           <div class="text-box">
             <p><strong class="menu-title"> Milkshakes (ask about flavors) </strong></p>
           </div>
           <strong class="amount">$6.99 </strong> </div>
         <!-- #Text box-->






         
            <!-- Text box-->
            <div class="text-box-outer">
           
         
           <div class="text-box">
             <p><strong class="menu-title"> Ask about our Boozy Milkshakes </strong></p>
           </div>
           <strong class="amount"> (in-house only) </strong> </div>
         <!-- #Text box-->

        



        </div>
        <!-- Text col-->
      </div>
      <!-- #menu box-->
    </div>
    <!--- #first col -->
  </div>
  <!--- #container -->

  
  <p class="text-center mx-5" style="    clear: both;
    margin: 7% 0 0 0;
    display: block;">Chet Patel</p>

    
  </section>
</div>
<!--Main-->
<?php include 'footer.php'; ?>