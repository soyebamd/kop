<script>

const replaceURLS = [
    '/newsletter'
    
   ];


for(index of replaceURLS ){
 if(window.location.pathname.includes(index)){
        window.location.href= 'https://kopgrillandtavern.com/'
  };
}


</script>