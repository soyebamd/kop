<script>

const replaceURLS = [
    '/coming-soon'
    
   ];


for(index of replaceURLS ){
 if(window.location.pathname.includes(index)){
        window.location.href= 'https://kopgrillandtavern.com/'
  };
}


</script>