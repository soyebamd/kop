<?php 
$title = 'King of Prussia Tavern Menu';
include 'header.php'; ?>
<!--Main-->
<div id="main">
  <!--TAB STYLE 1-->
  <!--MENU-->
  <section class="tab-style-2">
    <!-- container -->
    <div class="container">
      <!-- row -->
      <div class="row">
        <!--- first col -->
        <div class="col-md-6 col-xs-12">
          <!-- menu box-->
          <div class="menu-box">
            <!-- Text col-->
            <div class="text-col">
              <h2>Soups</h2>
              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title"> TODAY'S SELECTION </strong><br>
                    </p>
                </div>
                <strong class="amount">$7.00</strong> 
               </div>
              <!-- #Text box-->


              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title"> FRENCH ONION SOUP </strong><br>
                  <small>   Swiss, Provolone, Crostini </small> </p>
                </div>
                <strong class="amount">$8.00 </strong> </div>
              <!-- #Text box-->


               




             
            </div>
            <!-- Text col-->
            <div class="text-col m-top-5">
              <h2>Salads</h2>
              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title"> MIXED GREENS </strong><br>
                  <small>     Tomato, Cucumber, Carrot, Croutons, Maple Mustard 
                    Vinaigrette </small></p>
                </div>
                <strong class="amount">$8.00 </strong> </div>
              <!-- #Text box-->
              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title"> CAESAR SALAD </strong><br>
                  <small>  Torn Romaine, Housemade Caesar Dressing, Croutons, Parm <br>Add: </small>
                  <ul class="text-light ms-4" >
                    <li>Chicken +5</li>
                    <li>Grilled Shrimp +6</li>
                    <li>Grilled Salmon +8</li>
                    
                  </ul>
                  </p>
                </div>
                <strong class="amount">$9.00 </strong> </div>
              <!-- #Text box-->
              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title"> BLACKENED CHICKEN CHOP SALAD </strong><br>
                  <small>  Avocado Ranch, Tomato, Black Beans, Tortilla Chips, Cheddar
                    Jack Cheese  </small></p>
                </div>
                <strong class="amount">$14.00 </strong> </div>
              <!-- #Text box-->
              
              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">GREEK SALAD </strong><br>
                  <small>  Spring Mix, Feta, Tomato, Olives, Fresh Chicken, Croutons, 
                    Onion, Peppers, Red Wine Vinaigrette </small> </p>
                </div>
                <strong class="amount">$14.00 </strong> </div>
              <!-- #Text box-->


              
              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">BERRY SALAD </strong><br>
                  <small> Almonds, Blueberries, Strawberries, Feta Cheese,
Strawberry Vinaigrette </small> </p>
                </div>
                <strong class="amount">$14.00 </strong> </div>
              <!-- #Text box-->



            </div>
            <!-- #Text col-->
            <!-- Text col-->
            <div class="text-col m-top-5">
              <h2>Handhelds</h2>
              <p> All handhelds are available on a gluten free bun or lettuce wrap</p>
              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">ANGUS BURGER </strong><br>
                  <small>Grilled Angus Beef topped with Cheddar,
Lettuce, Tomato, Red Onion, and Pickles,
served with Coated Fries</small></p>
                </div>
                <strong class="amount">$14.00 </strong> </div>
              <!-- #Text box-->
              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">BEEF ON WECK </strong><br>
                    Tender Hot Roast Beef as jus, served on a Caraway Kaiser with Fresh 
                    Horseradish and House Fried Potato Chips </p>
                </div>
                <strong class="amount">$14.00 </strong> </div>
              <!-- #Text box-->
              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">GRILLED CHICKEN CLUB </strong><br>
                  <small> Grilled Chicken, Herb Mayo, Applewood Bacon, Whole Grain Toast, 
                    Creamy Cole Slaw, Lettuce, Tomato  </small></p>
                </div>
                <strong class="amount">$14.00 </strong> </div>
              <!-- #Text box-->
              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">CRISPY FRIED WHITEFISH</strong><br>
                    Golden Brown Fish Filet, Green Tabasco Remoulade, Lettuce, 
                    Tomato, Pickles, House Fried Potato Chips </p>
                </div>
                <strong class="amount">$12.00 </strong> </div>
              <!-- #Text box-->
              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">LEAN TURKEY BURGER</strong><br>
                <small>  Teriyaki Glaze, Grilled Red Onion, and Pineapple
with a Mixed Salad</small> </p>
                </div>
                <strong class="amount">$12.00 </strong> </div>
              <!-- #Text box-->
              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">CLASSIC CHEESESTEAK</strong><br>
                  <small>  Cooper Sharp, Caramelized Onion, Long Roll, Crispy Fries  </small></p>
                </div>
                <strong class="amount">$13.00 </strong> </div>
              <!-- #Text box-->
              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">BUFFALO CHICKEN CHEESESTEAK</strong><br>
                  <small> Crumbled Blue Cheese, Buffalo Sauce, Long Roll, Crispy Fries  </small></p>
                </div>
                <strong class="amount">$13.00 </strong> </div>
              <!-- #Text box-->
              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">BLACK BEAN BURGER <small>(Vegan)</small></strong><br>
                    House Made Black Bean and Rice Burger on a Kaiser, Shredded 
                    Lettuce, Hand Cut Pico de Gallo, Guacamole, Crispy Tortilla Chips </p>
                </div>
                <strong class="amount">$10.00 </strong> </div>
              <!-- #Text box-->
              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">NORTH CAROLINA PULLED PORK</strong><br>
                  <small>  Sweet and Spicy Vinegar BBQ Sauce, toasted Kaiser Roll, Creamy 
                    Cole Slaw  </small></p>
                </div>
                <strong class="amount">$11.00 </strong> </div>
              <!-- #Text box-->
              <!-- Text box-->
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">SAVORY FRIED CHICKEN SANDWICH</strong><br>
                  <small>  Lettuce, Tomato, Pickle, House Fried Potato Chips, Garlic Aioli </small></p>
                </div>
                <strong class="amount">$12.00 </strong> </div>
              <!-- #Text box-->
              <!-- Text box
              <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">GOLDEN SEARED CRAB CAKE</strong><br>
                    Toasted Brioche, Green Tabasco Remoulade, Lettuce, Tomato, House 
                    Fried Potato Chips </p>
                </div>
                <strong class="amount">$18.00 </strong> </div>
               #Text box-->
              <!-- Text box-->

               <!-- Text box-->
               <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">GRILLED CHEESE</strong><br>
                 <small>  Add +5: Pulled Pork, Angus Burger, or Sliced Steak  </small> </p>
                </div>
                <strong class="amount">$9.00 </strong> </div>
              <!-- #Text box-->



              
               <!-- Text box-->
               <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">CHICKEN SALAD CLUB SANDWICH</strong><br>
                 <small>  Multigrain Toast, Lettuce, Tomato, Bacon, Chips </small> </p>
                </div>
                <strong class="amount">$14.00 </strong> </div>
              <!-- #Text box-->


              

              
               <!-- Text box-->
               <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">GRILLED CHICKEN SANTE FE</strong><br>
                 <small> Spinach, Tomato, Provolone, Avocado,
and Chipotle on Ciabatta Bread</small> </p>
                </div>
                <strong class="amount">$16.00 </strong> </div>
              <!-- #Text box-->


              
              
              
               <!-- Text box-->
               <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">FISH TACO (3pc) </strong><br>
                </p>
                </div>
                <strong class="amount">$12.00 </strong> </div>
              <!-- #Text box-->



              

               <!-- Text box-->
               <div class="text-box-outer">
                <div class="text-box">
                  <p><strong class="menu-title">BLT </strong><br>
                </p>
                </div>
                <strong class="amount">$10.00 </strong> </div>
              <!-- #Text box-->








<div class="m-top-5" style="display:inline-block; clear:both; ">
            <h2> Fit for a king or queen </h2>
            </div>
              <div style="border: solid 1px #fff;
display: block;
clear: both;
float: left;
width: 100%;
margin: 22px -10px;
padding: 10px;">
                <!-- Text box-->
                <div class="text-box-outer m-0">
                  <div class="text-box">
                    <p><strong class="menu-title">SWEETWATER GRILLED CHEESE <small>(Vegetarian)</small> </strong><br>
                      Three Thick Slices of Texas Toast filled with a pound total of Cooper 
                      Sharp, Cheddar, Swiss and Provolone. Served with a pound of 
                      Seasoned Fries </p>
                  </div>
                  <strong class="amount">$25.00 </strong> </div>
                <!-- #Text box-->
                <!-- Text box-->
                <div class="text-box-outer ">
                  <div class="text-box">
                    <p><strong class="menu-title">TRIPLE BACON CHEESEBURGER </strong><br>
                      Three of our Half Pound Patties with a half pound of Bacon, Cheddar, 
                      American, and Swiss Cheeses, and served with a pound of Seasoned 
                      Fries </p>
                  </div>
                  <strong class="amount">$35.00 </strong> </div>
                <!-- #Text box-->
                <!-- Text box-->
                <div class="text-box-outer ">
                  <div class="text-box">
                    <p><strong class="menu-title">WHAT THE CLUCK CHICKEN SANDWICH</strong><br>
                      Three of our Golden Fried Chicken Breasts smothered in Orange 
                      Habanero and Buffalo Sauce, and served on a Long Roll with Ranch, 
                      Crumbled Blue Cheese, and a pound of seasoned fries </p>
                  </div>
                  <strong class="amount">$35.00 </strong> </div>
                <!-- #Text box-->
              </div>
            </div>
            <!-- #Text col-->
          </div>
          <!-- #menu box-->
        </div>
        <!--- #first col -->
        <!--- second col -->
      
      <!--- #second col -->
    </div>
    <!--- #container -->


    
  <p class="text-center mx-5" style="    clear: both;
    margin: 7% 0 0 0;
    display: block;">Chet Patel</p>

    
  </section>
</div>
<!--Main-->
<?php include 'footer.php'; ?>