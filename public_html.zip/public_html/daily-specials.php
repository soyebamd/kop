<?php 
$title = 'Daily Specials';
include 'header.php'; ?>
<!--Main-->
<div id="main">
<!--TAB STYLE 1-->
<!--MENU-->
<section class="tab-style-2">
<!-- container -->
<div class="container ">
  <!-- row -->
  <div class="row">
    <!--- first col -->
    <div class="col-md-12 col-xs-12">
      <!-- menu box-->
      <div class="menu-box">
        <!-- Text col-->
        <div class="text-col mx-auto">
          <h2> Daily Specials</h2>

 <!-- Text box-->
          <div class="text-box-outer">
            <div class="text-box">
              <p><strong class="menu-title">BOGO MONDAY </strong><br>
              </p>

              <p>Buy One Meatloaf and/or Pot Roast,
& get the second Meatloaf and/or Pot Roast free</p>
                
             
            </div>
            </div>
          <!-- #Text box-->




          <!-- Text box-->
          <div class="text-box-outer">
            <div class="text-box full-width">
              <p><strong class="menu-title">TACO TUESDAY </strong><br>
              </p>

              <p class="display2"><small>Seared Beef or Chicken</small> <strong class="pull-right">$1.00</strong></p>
              <p class="display2"><small>Fried Fish </small> <strong class="pull-right">$2.50</strong></p>            
             
            </div>
            </div>
          <!-- #Text box-->





          
 <!-- Text box-->
          <div class="text-box-outer">
            <div class="text-box">
              <p><strong class="menu-title">FRIED CHICKEN WEDNESDAY </strong><br>
              </p>

              <p>Free glass of select wine or draft beer
with purchase of a fried chicken entree</p>
                
             
            </div>
            </div>
          <!-- #Text box-->







          <!-- Text box-->
          <div class="text-box-outer">
            <div class="text-box full-width">
              <p><strong class="menu-title">PRIME RIB THURSDAY </strong><br>
              </p>

              <p class="display2"><small>Succulent Prime Rib with Baked Potato
& Au Jus</small> <strong class="pull-right">$32.00</strong></p>
              <p class="display2"><small>Select Draft Beers </small> <strong class="pull-right">$3.00</strong></p>            
             
            </div>
            </div>
          <!-- #Text box-->



        </div>
        <!-- Text col-->
      </div>
      <!-- #menu box-->
    </div>
    <!--- #first col -->
  </div>
  <!--- #container -->


  
  <p class="text-center mx-5" style="    clear: both;
    margin: 7% 0 0 0;
    display: block;">Chet Patel</p>

    
  </section>
</div>
<!--Main-->
<?php include 'footer.php'; ?>