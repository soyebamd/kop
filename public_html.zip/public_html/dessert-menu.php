<?php 
$title = 'King of Prussia Tavern Desserts';
include 'header.php'; ?>
<!--Main-->
<div id="main">
<!--TAB STYLE 1-->
<!--MENU-->
<section class="tab-style-2">
<!-- container -->
<div class="container ">
  <!-- row -->
  <div class="row">
    <!--- first col -->
    <div class="col-md-12 col-xs-12">
      <!-- menu box-->
      <div class="menu-box">
        <!-- Text col-->
        <div class="text-col mx-auto">
          <h2>Dessert Menu</h2>








          <!-- Text box-->
          <div class="text-box-outer">
                       <div class="text-box">
              <p><strong class="menu-title">Ice Cream  </strong><br>
                <small>Vanilla, Chocolate, Strawberry</small></p>
            </div>
            <strong class="amount">$5.00 </strong> </div>
          <!-- #Text box-->
          



          


          <!-- Text box-->
          <div class="text-box-outer">
                       <div class="text-box">
              <p><strong class="menu-title">Skillet Brownie A La mode   </strong><br>
                <small>Vanilla, Chocolate, Strawberry</small></p>
            </div>
            <strong class="amount">$7.00 </strong> </div>
          <!-- #Text box-->




          

          <!-- Text box-->
          <div class="text-box-outer">
                       <div class="text-box">
              <p><strong class="menu-title">Ask about our specialty Skillet Brownies including Smores!   </strong><br>
                </p>
            </div>
          </div>
          <!-- #Text box-->
          
          




          <!-- Text box-->
          <div class="text-box-outer">
                       <div class="text-box">
              <p><strong class="menu-title">Ask about our seasonal desserts, including Milkshakes, Boozy Milkshakes, and more! </strong><br>
                </p>
            </div>
          </div>
          <!-- #Text box-->
          
          
          




        </div>
        <!-- Text col-->

       
      </div>

      <!-- #menu box-->
    </div>
    <!--- #first col -->
  </div>
  <!--- #container -->

  
  <p class="text-center mx-5" style="    clear: both;
    margin: 7% 0 0 0;
    display: block;">Chet Patel</p>


  </section>
</div>
<!--Main-->
<?php include 'footer.php'; ?>