<?php 
$title = 'Pizza';
include 'header.php'; ?>
<!--Main-->
<div id="main">
<!--TAB STYLE 1-->
<!--MENU-->
<section class="tab-style-2">
<!-- container -->
<div class="container ">
  <!-- row -->
  <div class="row">
    <!--- first col -->
    <div class="col-md-12 col-xs-12">
      <!-- menu box-->
      <div class="menu-box">
        <!-- Text col-->
        <div class="text-col mx-auto">
          <h2>Pizza</h2>

          <!-- Text box with CSS to make text uppercase -->
          <div class="text-box-outer">
            <div class="text-box">
              <p><strong class="menu-title">BUFFALO CHICKEN PIZZA</strong><br>
                <small>Chicken, Buffalo sauce, Ranch, Blue cheese crumbles</small></p>
            </div>
            <strong class="amount">$18.00 </strong> 
          </div>
          <!-- #Text box-->

          <!-- Text box with CSS to make text uppercase -->
          <div class="text-box-outer">
            <div class="text-box">
              <p><strong class="menu-title">TRADITIONAL PIZZA</strong><br>
            </div>
            <strong class="amount">$14.00 </strong> 
          </div>
          <!-- #Text box-->

          <!-- Text box with CSS to make text uppercase -->
          <div class="text-box-outer">
            <div class="text-box">
              <p><strong class="menu-title">MARGHERITA PIZZA</strong><br>
                <small>garlic, tomatoes, fresh mozzarella, basil</small></p>
            </div>
            <strong class="amount">$15.00 </strong> 
          </div>
          <!-- #Text box-->

          <!-- Text box with CSS to make text uppercase -->
          <div class="text-box-outer">
            <div class="text-box">
              <p><strong class="menu-title">BREAKFAST PIZZA</strong><br>
                <small>Scrambled egg, Mozzarella, Bacon, Sausage</small></p>
            </div>
            <strong class="amount">$16.00 </strong> 
          </div>
          <!-- #Text box-->

          <!-- Text box with CSS to make text uppercase -->
          <div class="text-box-outer">
            <div class="text-box">
              <p><strong class="menu-title">TOPPINGS</strong><br>
                <small>pepperoni</small> <br>
                <small>grilled chicken</small> <br>
                <small>sausage</small> <br>
                <small>jalapenos</small> <br>
                <small>mushrooms</small> <br>
              </p>
            </div>
            <strong class="amount">$2.00 </strong> 
          </div>
          <!-- #Text box-->

          <!-- Text box with CSS to make text uppercase -->
          <div class="text-box-outer">
            <div class="text-box">
            <p><strong class="menu-title">Ask about our specialty Skillet Brownies including Smores!   </strong><br>
              </p>
            </div>
          </div>
          <!-- #Text box-->
          
        </div>
        <!-- Text col-->
       
      </div>
      <!-- #menu box-->
    </div>
    <!--- #first col -->
  </div>
  <!--- #container -->


</section>
</div>
<!--Main-->
<?php include 'footer.php'; ?>
