<!--HOME GALLERY-->
<section class="home-gallery gallery">
  <div class="img-frame"> <img src="images/Fried-Shrimp-King-of-Prussia-KOP-Tavern-2.png" alt="">
    <!--<div class="caption">
          <div class="holder"> <a href="images/gallery-home-img-1.jpg" class="link" data-rel="prettyPhoto"><i class="fa fa-search" aria-hidden="true"></i></a> <a href="gallery-masonry.php" class="link"><i class="fa fa-link" aria-hidden="true"></i></a> </div>
        </div>-->
  </div>
  <div class="img-frame"> <img src="images/BLT-King-of-Prussia-KOP-Tavern-2.png" alt=""> </div>
  <div class="img-frame"> <img src="images/Burgers-King-of-Prussia-KOP-Tavern-2.png" alt=""> </div>
  <div class="img-frame"> <img src="images/Grilled-Shrimp-King-of-Prussia-KOP-Tavern-2.png" alt=""> </div>
  <div class="img-frame"> <img src="images/Cheesesteak-KOP-Tavern-2.png" alt=""> </div>
</section>
<!--HOME GALLERY-->